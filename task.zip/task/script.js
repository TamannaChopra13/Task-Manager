const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const totalTasksCount = document.getElementById("totalTasks");
const completedTasksCount = document.getElementById("completedTasks");

let totalTasks = 0;
let completedTasks = 0;
window.addEventListener('load' , loadtasks);

function loadtasks(){
  console.log("loading...................................");
  let tasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : [];
  let ul = document.getElementById("taskList");
  let tt = parseInt(localStorage.getItem("totalTasks"));
  console.log("totaltasks : ", tt);
  document.getElementById("totalTasks").innerHTML = tt;
  
  for(let task of tasks){
    let li = document.createElement("li");
    li.classList.add("task-item");
    li.innerHTML = `<input type="checkbox" class="task-checkbox form-check-input">
    <span class="ta">${task.taskText}</span>
    <span class="da">${task.p}</span>
    <span class="ca">${task.c}</span>
    <button type="button" class="edit-btn btn btn-dark my-2" onclick="editTask(this)">Edit</button>
    <button type="button" class="delete-btn btn btn-dark my-2">Delete</button>
    `;
    li.classList.add('li');
    ul.append(li);
  }
}
// Update the task count
function updateTaskCount() {
  totalTasksCount.textContent = totalTasks;
  completedTasksCount.textContent = completedTasks;
  localStorage.setItem('totalTasks', totalTasks); 
}

// Add a new task
function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText !== "") {
    const taskItem = document.createElement("li");
    taskItem.classList.add("task-item");
    let p = document.getElementById("date").value;
    let c=document.getElementById("cate").value;
    taskItem.innerHTML = `
    <input type="checkbox" class="task-checkbox form-check-input">
    <span class="ta">${taskText}</span>
    <span class="da">${p}</span>
    <span class="ca">${c}</span>
    <button type="button" class="edit-btn btn btn-dark my-2" on click="editTask(this)">Edit</button>
    <button type="button" class="delete-btn btn btn-dark my-2">Delete</button>
    
    `;
    taskList.appendChild(taskItem);
    taskInput.value = "";
    totalTasks++;
    updateTaskCount();
    saveData(taskText , p , c ,totalTasks);
    
    // Trigger animation for new task item
    taskItem.style.animation = "fade-in 0.3s ease-in forwards";
  }
  
}

// Delete a task
function deleteTask(event) {
  if (event.target.classList.contains("delete-btn")) {
    const taskItem = event.target.parentElement;
    taskItem.style.animation = "fade-out 0.3s ease-in forwards";
    
    setTimeout(() => {
      taskList.removeChild(taskItem);
    }, 300);
    
    let tasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : []; 
    const taskIndex = Array.from(taskItem.parentNode.children).indexOf(taskItem);
    tasks.splice(taskIndex, 1);    
    localStorage.setItem('tasks', JSON.stringify(tasks));
    totalTasks = parseInt(localStorage.getItem("totalTasks")) - 1;
    document.getElementById("totalTasks").innerHTML = totalTasks;
    localStorage.setItem('totalTasks', totalTasks); 
    updateTaskCount();
    
  }
}


// Mark a task as completed
function completeTask(event) {
  if (event.target.classList.contains("task-checkbox")) {
    const taskItem = event.target.parentElement;
    taskItem.classList.toggle("completed");
    if (taskItem.classList.contains("completed")) {
      completedTasks++;
    } else {
      completedTasks--;
    }
    updateTaskCount();
  }
}

// Event listeners
taskInput.addEventListener("keydown", function (event) {
  if (event.keyCode === 13) {
    // Enter key
    addTask();
  }
});

taskList.addEventListener("click", function (event) {
  deleteTask(event);
  completeTask(event);
});

const searchInput = document.getElementById("searchInput");
searchInput.addEventListener("input", searchTasks);

function searchTasks() {
  //console.log("search");
  const searchQuery = searchInput.value.toLowerCase();
  
  const taskItems = taskList.querySelectorAll("ul li");
  
  taskItems.forEach(taskItem => {
    const taskText = taskItem.textContent.toLowerCase();
    
    if (taskText.includes(searchQuery)) {
      // taskItem.classList.add("task-item");
      taskItem.style.display = "block";
    } else {
      taskItem.style.display = "none";
        }
    });
}
// const sortByDate()
function saveData(taskText, p, c, totalTasks) {
  let tasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : [];
  tasks.push({ taskText, p, c });
  localStorage.setItem('tasks', JSON.stringify(tasks));


}

// ...

// Edit a task
// ...

// Edit a task
function editTask(i) {
  let taskText = i.closest("li").querySelector(".ta").textContent;
  let dateText = i.closest("li").querySelector(".da").innerText;
  let selText = i.closest("li").querySelector(".ca").textContent;

  document.getElementById("taskInput").value = taskText;
  document.getElementById("date").value = dateText;
  document.getElementById("cate").value = selText;

  // toaddtask();
}

function sortTasksByDate(tasks) {
  return tasks.sort((a, b) => {
      return new Date(a.p) - new Date(b.p);
      });
  }

  function sortAndReloadTasks() {
  let tasks = localStorage.getItem('tasks') ? JSON.parse(localStorage.getItem('tasks')) : [];
  tasks = sortTasksByDate(tasks);

  localStorage.setItem('tasks', JSON.stringify(tasks)); // Update the sorted tasks in local storage
  loadtasks();
  for(let task of tasks){
      let li = document.querySelector("li");
      li.remove(); // Reload the tasks list

  }
}